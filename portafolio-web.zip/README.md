# Portafolio · Cecilia Blanco

Sitio estático (HTML + CSS + JS), listo para GitHub Pages. No necesita build.

## Publicar en GitHub Pages
1. Subí **todo el contenido de esta carpeta** a un repositorio (en la raíz).
2. En el repo: *Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)`*.
3. En un par de minutos queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Qué editar (todo está en `js/data.js`)
- `SITE`: nombre, iniciales, correo, redes y enlace a tu carpeta de Drive.
- `PROYECTOS`: un objeto por video. Pegá el enlace de compartir en `drive` y ese video se reproduce dentro del sitio.
  Cada video de Drive tiene que estar compartido como *"Cualquier persona con el enlace"*, si no el reproductor muestra un error de Google.
- Los títulos de los proyectos son provisorios (salen de los nombres de archivo): revisalos.
- Tu foto: guardala como `assets/foto.jpg` (se muestra en blanco y negro).
- Textos de "Sobre mí" y "Servicios": en `index.html`.

Los videos **no** se suben al repo (GitHub Pages tiene límite de ~1 GB): se reproducen desde Drive. En `assets/thumbs/` están las miniaturas livianas.
