/* ============================================================
   CONTENIDO EDITABLE: todo lo que cambia en el sitio está acá.
   ============================================================ */
const SITE = {
  nombre: "Cecilia Blanco",
  iniciales: "CB",
  rol: "Edición · Diseño · Contenido",
  email: "tuemail@ejemplo.com",          // ← cambiá por tu correo
  instagram: "https://instagram.com/tuusuario",
  tiktok: "https://tiktok.com/@tuusuario",
  linkedin: "https://linkedin.com/in/tuusuario",
  carpetaDrive: "https://drive.google.com/drive/folders/1fNBiiAvh-JwQyWq3IudeLXkRz-0OBgAH?usp=sharing",
  destacado: "simple-comercio" // id del proyecto destacado
};

const CATEGORIAS = {
  "marcas": "Marcas y e-commerce",
  "moda": "Moda, lujo y retail",
  "salud": "Salud y servicios",
  "inmo": "Inmobiliarias",
  "fitness": "Fitness y bienestar",
  "campanas": "Campañas y series"
};

/* Cada proyecto: pegá en "drive" el enlace de compartir del video
   (Drive → botón derecho en el video → Compartir → "Cualquier persona con el enlace").
   Sirve cualquier formato de enlace de Drive. */
const PROYECTOS = [
 {
  "id": "0914-1",
  "title": "Relojes: por qué los usan los famosos",
  "cat": "campanas",
  "dur": 24,
  "vertical": true,
  "thumb": "assets/thumbs/01-0914-1.jpg",
  "drive": ""
 },
 {
  "id": "0923-1",
  "title": "La historia de Patek Philippe",
  "cat": "campanas",
  "dur": 35,
  "vertical": true,
  "thumb": "assets/thumbs/02-0923-1.jpg",
  "drive": ""
 },
 {
  "id": "0928-1",
  "title": "Rolex: por qué se fue el Pepsi",
  "cat": "campanas",
  "dur": 24,
  "vertical": true,
  "thumb": "assets/thumbs/03-0928-1.jpg",
  "drive": ""
 },
 {
  "id": "1-cari-no-1",
  "title": "Funkos: ideas de regalo",
  "cat": "campanas",
  "dur": 25,
  "vertical": true,
  "thumb": "assets/thumbs/04-1-cari-no-1.jpg",
  "drive": ""
 },
 {
  "id": "1006-1",
  "title": "Omega: James Bond vs. Spectre",
  "cat": "campanas",
  "dur": 32,
  "vertical": true,
  "thumb": "assets/thumbs/05-1006-1.jpg",
  "drive": ""
 },
 {
  "id": "2-cari-no-2",
  "title": "Funkos: para tu pareja",
  "cat": "campanas",
  "dur": 24,
  "vertical": true,
  "thumb": "assets/thumbs/06-2-cari-no-2.jpg",
  "drive": ""
 },
 {
  "id": "3-cari-no-3",
  "title": "Funkos: regalos que no fallan",
  "cat": "campanas",
  "dur": 25,
  "vertical": true,
  "thumb": "assets/thumbs/07-3-cari-no-3.jpg",
  "drive": ""
 },
 {
  "id": "4-cari-no-4",
  "title": "Funkos: para ese día",
  "cat": "campanas",
  "dur": 24,
  "vertical": true,
  "thumb": "assets/thumbs/08-4-cari-no-4.jpg",
  "drive": ""
 },
 {
  "id": "relojes",
  "title": "3 relojes de lujo para tu novio",
  "cat": "campanas",
  "dur": 31,
  "vertical": true,
  "thumb": "assets/thumbs/09-relojes.jpg",
  "drive": ""
 },
 {
  "id": "rolex",
  "title": "Reloj de lujo: más que una corona",
  "cat": "campanas",
  "dur": 19,
  "vertical": true,
  "thumb": "assets/thumbs/10-rolex.jpg",
  "drive": ""
 },
 {
  "id": "tomas-snoopy-2",
  "title": "Tomas de producto: Omega",
  "cat": "campanas",
  "dur": 15,
  "vertical": true,
  "thumb": "assets/thumbs/11-tomas-snoopy-2.jpg",
  "drive": ""
 },
 {
  "id": "feliz-2023-primitivo-gym",
  "title": "Saludo de año nuevo para un gimnasio",
  "cat": "fitness",
  "dur": 15,
  "vertical": true,
  "thumb": "assets/thumbs/12-feliz-2023-primitivo-gym.jpg",
  "drive": ""
 },
 {
  "id": "gymprimitivo",
  "title": "Saludo navideño para un gimnasio",
  "cat": "fitness",
  "dur": 10,
  "vertical": true,
  "thumb": "assets/thumbs/13-gymprimitivo.jpg",
  "drive": ""
 },
 {
  "id": "04-1-2-1",
  "title": "Inmobiliaria: el error al comprar casa",
  "cat": "inmo",
  "dur": 67,
  "vertical": true,
  "thumb": "assets/thumbs/14-04-1-2-1.jpg",
  "drive": ""
 },
 {
  "id": "06-1-1-1",
  "title": "Inmobiliaria: la clienta que evitó perder plata",
  "cat": "inmo",
  "dur": 47,
  "vertical": true,
  "thumb": "assets/thumbs/15-06-1-1-1.jpg",
  "drive": ""
 },
 {
  "id": "06-2-1",
  "title": "Inmobiliaria: recorrido de propiedad",
  "cat": "inmo",
  "dur": 62,
  "vertical": true,
  "thumb": "assets/thumbs/16-06-2-1.jpg",
  "drive": ""
 },
 {
  "id": "1inmo",
  "title": "Inmobiliaria: cuidado al elegir casa",
  "cat": "inmo",
  "dur": 37,
  "vertical": true,
  "thumb": "assets/thumbs/17-1inmo.jpg",
  "drive": ""
 },
 {
  "id": "copia-de-02-1-1",
  "title": "Inmobiliaria: el peor error",
  "cat": "inmo",
  "dur": 56,
  "vertical": true,
  "thumb": "assets/thumbs/18-copia-de-02-1-1.jpg",
  "drive": ""
 },
 {
  "id": "copia-de-06-2-1-copia",
  "title": "Inmobiliaria: elegir la casa equivocada",
  "cat": "inmo",
  "dur": 37,
  "vertical": true,
  "thumb": "assets/thumbs/19-copia-de-06-2-1-copia.jpg",
  "drive": ""
 },
 {
  "id": "1-video-facundo-1",
  "title": "Video de marca personal",
  "cat": "marcas",
  "dur": 24,
  "vertical": true,
  "thumb": "assets/thumbs/20-1-video-facundo-1.jpg",
  "drive": ""
 },
 {
  "id": "conocimientosimple",
  "title": "Conocimiento Simple: presentación",
  "cat": "marcas",
  "dur": 56,
  "vertical": true,
  "thumb": "assets/thumbs/21-conocimientosimple.jpg",
  "drive": ""
 },
 {
  "id": "cs",
  "title": "Conocimiento Simple: reel",
  "cat": "marcas",
  "dur": 33,
  "vertical": true,
  "thumb": "assets/thumbs/22-cs.jpg",
  "drive": ""
 },
 {
  "id": "conocimiento-simple-it",
  "title": "Conocimiento Simple: IT",
  "cat": "marcas",
  "dur": 47,
  "vertical": true,
  "thumb": "assets/thumbs/23-conocimiento-simple-it.jpg",
  "drive": ""
 },
 {
  "id": "historia-simple-comercio",
  "title": "Simple Comercio: historia",
  "cat": "marcas",
  "dur": 98,
  "vertical": true,
  "thumb": "assets/thumbs/24-historia-simple-comercio.jpg",
  "drive": ""
 },
 {
  "id": "simple-comercio",
  "title": "Simple Comercio: video de marca",
  "cat": "marcas",
  "dur": 97,
  "vertical": false,
  "thumb": "assets/thumbs/25-simple-comercio.jpg",
  "drive": ""
 },
 {
  "id": "ares-educ",
  "title": "Ares: contenido educativo",
  "cat": "marcas",
  "dur": 25,
  "vertical": true,
  "thumb": "assets/thumbs/26-ares-educ.jpg",
  "drive": ""
 },
 {
  "id": "ares1",
  "title": "Ares: pieza 1",
  "cat": "marcas",
  "dur": 13,
  "vertical": true,
  "thumb": "assets/thumbs/27-ares1.jpg",
  "drive": ""
 },
 {
  "id": "ares2",
  "title": "Ares: pieza 2",
  "cat": "marcas",
  "dur": 30,
  "vertical": true,
  "thumb": "assets/thumbs/28-ares2.jpg",
  "drive": ""
 },
 {
  "id": "0619k19",
  "title": "Ventas: habilidades para dominar",
  "cat": "moda",
  "dur": 33,
  "vertical": true,
  "thumb": "assets/thumbs/29-0619k19.jpg",
  "drive": ""
 },
 {
  "id": "5-birkinhist",
  "title": "La marca detrás de un Birkin",
  "cat": "moda",
  "dur": 79,
  "vertical": true,
  "thumb": "assets/thumbs/30-5-birkinhist.jpg",
  "drive": ""
 },
 {
  "id": "5-roma",
  "title": "Roma: pieza de marca",
  "cat": "moda",
  "dur": 26,
  "vertical": true,
  "thumb": "assets/thumbs/31-5-roma.jpg",
  "drive": ""
 },
 {
  "id": "funkos",
  "title": "Funkos: coleccionables",
  "cat": "moda",
  "dur": 17,
  "vertical": true,
  "thumb": "assets/thumbs/32-funkos.jpg",
  "drive": ""
 },
 {
  "id": "funkos2",
  "title": "Funkos: colección",
  "cat": "moda",
  "dur": 21,
  "vertical": true,
  "thumb": "assets/thumbs/33-funkos2.jpg",
  "drive": ""
 },
 {
  "id": "gucci",
  "title": "Gucci: detalle de producto",
  "cat": "moda",
  "dur": 12,
  "vertical": true,
  "thumb": "assets/thumbs/34-gucci.jpg",
  "drive": ""
 },
 {
  "id": "lv",
  "title": "Louis Vuitton: un reel corto",
  "cat": "moda",
  "dur": 6,
  "vertical": true,
  "thumb": "assets/thumbs/35-lv.jpg",
  "drive": ""
 },
 {
  "id": "lv1",
  "title": "Louis Vuitton: la cartera",
  "cat": "moda",
  "dur": 12,
  "vertical": true,
  "thumb": "assets/thumbs/36-lv1.jpg",
  "drive": ""
 },
 {
  "id": "oklok-1",
  "title": "Estudio de diseño: recorrido",
  "cat": "moda",
  "dur": 20,
  "vertical": true,
  "thumb": "assets/thumbs/37-oklok-1.jpg",
  "drive": ""
 },
 {
  "id": "oklok-2",
  "title": "Showroom: ambientes",
  "cat": "moda",
  "dur": 22,
  "vertical": true,
  "thumb": "assets/thumbs/38-oklok-2.jpg",
  "drive": ""
 },
 {
  "id": "oklok-3",
  "title": "Showroom: detalle",
  "cat": "moda",
  "dur": 9,
  "vertical": true,
  "thumb": "assets/thumbs/39-oklok-3.jpg",
  "drive": ""
 },
 {
  "id": "oklok",
  "title": "Estudio de diseño: pieza",
  "cat": "moda",
  "dur": 15,
  "vertical": true,
  "thumb": "assets/thumbs/40-oklok.jpg",
  "drive": ""
 },
 {
  "id": "patek",
  "title": "Patek Philippe: la historia",
  "cat": "moda",
  "dur": 60,
  "vertical": true,
  "thumb": "assets/thumbs/41-patek.jpg",
  "drive": ""
 },
 {
  "id": "6-dental-sep",
  "title": "Odontología: consultorio",
  "cat": "salud",
  "dur": 32,
  "vertical": true,
  "thumb": "assets/thumbs/42-6-dental-sep.jpg",
  "drive": ""
 },
 {
  "id": "8-dental-sep",
  "title": "Odontología: carillas",
  "cat": "salud",
  "dur": 31,
  "vertical": true,
  "thumb": "assets/thumbs/43-8-dental-sep.jpg",
  "drive": ""
 },
 {
  "id": "julio-rivera-36",
  "title": "Contenido para redes: hashtags",
  "cat": "salud",
  "dur": 43,
  "vertical": true,
  "thumb": "assets/thumbs/44-julio-rivera-36.jpg",
  "drive": ""
 },
 {
  "id": "julio-rivera-39",
  "title": "Contenido para redes: crear sin vergüenza",
  "cat": "salud",
  "dur": 32,
  "vertical": true,
  "thumb": "assets/thumbs/45-julio-rivera-39.jpg",
  "drive": ""
 },
 {
  "id": "opravy",
  "title": "Opravy: pieza animada",
  "cat": "salud",
  "dur": 20,
  "vertical": true,
  "thumb": "assets/thumbs/46-opravy.jpg",
  "drive": ""
 },
 {
  "id": "pr-otesis-opravy",
  "title": "Opravy: impacto positivo",
  "cat": "salud",
  "dur": 29,
  "vertical": true,
  "thumb": "assets/thumbs/47-pr-otesis-opravy.jpg",
  "drive": ""
 },
 {
  "id": "reel-25-katherine-marroquin",
  "title": "Ventas: habilidades (versión 2)",
  "cat": "salud",
  "dur": 33,
  "vertical": true,
  "thumb": "assets/thumbs/48-reel-25-katherine-marroquin.jpg",
  "drive": ""
 },
 {
  "id": "juliofrase",
  "title": "Frase en texto animado",
  "cat": "salud",
  "dur": 5,
  "vertical": true,
  "thumb": "assets/thumbs/49-juliofrase.jpg",
  "drive": ""
 },
 {
  "id": "katherine",
  "title": "Psicología: el efecto del sentido",
  "cat": "salud",
  "dur": 29,
  "vertical": true,
  "thumb": "assets/thumbs/50-katherine.jpg",
  "drive": ""
 },
 {
  "id": "policia-facundo",
  "title": "Reel: la policía te busca",
  "cat": "salud",
  "dur": 42,
  "vertical": true,
  "thumb": "assets/thumbs/51-policia-facundo.jpg",
  "drive": ""
 },
 {
  "id": "psicologa",
  "title": "Psicología: emociones ignoradas en la infancia",
  "cat": "salud",
  "dur": 55,
  "vertical": true,
  "thumb": "assets/thumbs/52-psicologa.jpg",
  "drive": ""
 }
];
