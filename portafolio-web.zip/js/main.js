(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const PAGE = 8;
  let cat = 'todos', shown = PAGE, current = [], idx = 0, lastFocus = null;

  /* ---------- datos del sitio ---------- */
  document.querySelectorAll('[data-site]').forEach(el => el.textContent = SITE[el.dataset.site]);
  document.title = `${SITE.nombre} · Edición, diseño y contenido`;
  $('#year').textContent = new Date().getFullYear();
  const mail = `mailto:${SITE.email}`;
  const handle = u => '@' + u.replace(/\/+$/, '').split('/').pop().replace('@', '');
  $('#mail-btn').href = mail; $('#c-mail').href = mail; $('#c-mail').textContent = SITE.email;
  [['c-ig', 'instagram'], ['f-ig', 'instagram'], ['c-tt', 'tiktok'], ['f-tt', 'tiktok'], ['f-in', 'linkedin']].forEach(([id, k]) => {
    const a = $('#' + id); a.href = SITE[k]; if (id.startsWith('c-')) a.textContent = handle(SITE[k]);
  });
  document.querySelectorAll('img[data-proj]').forEach(img => {
    const p = PROYECTOS.find(x => x.id === img.dataset.proj); if (p) img.src = p.thumb;
  });

  /* ---------- menú móvil ---------- */
  const burger = $('#burger'), nav = $('#nav');
  const setMenu = open => {
    burger.setAttribute('aria-expanded', open); nav.classList.toggle('open', open);
    burger.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    document.body.classList.toggle('lock', open);
  };
  burger.addEventListener('click', () => setMenu(burger.getAttribute('aria-expanded') !== 'true'));
  nav.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && nav.classList.contains('open')) { setMenu(false); burger.focus(); } });
  matchMedia('(min-width: 861px)').addEventListener('change', () => setMenu(false));

  /* ---------- filtros ---------- */
  const cats = [['todos', 'Todos'], ...Object.entries(CATEGORIAS)];
  $('#chips').innerHTML = cats.map(([k, n]) => `<button type="button" data-cat="${k}" aria-pressed="${k === cat}">${n}</button>`).join('');
  $('#radios').innerHTML = cats.map(([k, n]) => `<label><input type="radio" name="cat" value="${k}" ${k === cat ? 'checked' : ''}><span>${n}</span></label>`).join('');
  const setCat = k => { cat = k; shown = PAGE; render(); };
  $('#chips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setCat(b.dataset.cat); });
  $('#radios').addEventListener('change', e => setCat(e.target.value));
  const more = () => { shown += PAGE; render(true); };
  $('#more').addEventListener('click', more); $('#more-hand').addEventListener('click', more);

  const fmt = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  function render(keepScroll) {
    current = cat === 'todos' ? PROYECTOS : PROYECTOS.filter(p => p.cat === cat);
    const list = current.slice(0, shown);
    $('#grid').className = 'grid' + (cat === 'todos' ? ' lead-big' : '');
    $('#grid').innerHTML = list.map((p, i) => `
      <article class="card ${p.vertical ? '' : 'wide'}">
        <button type="button" class="thumb" data-i="${i}" aria-label="Reproducir: ${p.title}">
          <img src="${p.thumb}" alt="" loading="lazy" width="480" height="${p.vertical ? 853 : 270}">
          <span class="play"><svg><use href="#play"/></svg></span><span class="dur">${fmt(p.dur)}</span>
        </button>
        <p class="cat">${CATEGORIAS[p.cat]}</p><h3>${p.title}</h3>
      </article>`).join('');
    document.querySelectorAll('#chips button').forEach(b => b.setAttribute('aria-pressed', b.dataset.cat === cat));
    document.querySelectorAll('#radios input').forEach(r => r.checked = r.value === cat);
    const left = current.length - list.length;
    $('#more').hidden = $('#more-hand').hidden = left <= 0;
    $('#count').textContent = `Mostrando ${list.length} de ${current.length}`;
  }
  $('#grid').addEventListener('click', e => { const b = e.target.closest('.thumb'); if (b) open(+b.dataset.i, b); });

  /* ---------- destacado ---------- */
  const fp = PROYECTOS.find(p => p.id === SITE.destacado) || PROYECTOS[0];
  $('#feat-img').src = fp.thumb; $('#feat-dur').textContent = fmt(fp.dur);
  $('#dest-t').textContent = fp.title.split(':')[0];
  $('.feat-copy .meta').textContent = CATEGORIAS[fp.cat];
  $('#feat-drive').href = driveView(fp.drive) || SITE.carpetaDrive;
  const openFeat = el => { cat = 'todos'; current = PROYECTOS; open(PROYECTOS.indexOf(fp), el); };
  $('#feat').addEventListener('click', e => openFeat(e.currentTarget));
  $('[data-open-featured]').addEventListener('click', e => openFeat(e.currentTarget));

  /* ---------- reproductor de Drive ---------- */
  function driveId(u) {
    if (!u) return null; u = u.trim();
    const m = u.match(/\/d\/([\w-]{10,})/) || u.match(/[?&]id=([\w-]{10,})/);
    return m ? m[1] : (/^[\w-]{20,}$/.test(u) ? u : null);
  }
  function driveView(u) { const id = driveId(u); return id ? `https://drive.google.com/file/d/${id}/view` : null; }
  const dlg = $('#player'), frame = $('#p-frame');
  function open(i, from) {
    if (!current.length) current = PROYECTOS;
    idx = (i + current.length) % current.length; lastFocus = from || lastFocus;
    const p = current[idx], id = driveId(p.drive);
    $('#p-title').textContent = p.title;
    frame.className = 'p-frame ' + (p.vertical ? 'vert' : 'horiz');
    frame.innerHTML = id
      ? `<iframe src="https://drive.google.com/file/d/${id}/preview" title="${p.title}" allow="autoplay; fullscreen" allowfullscreen></iframe>`
      : `<div class="p-empty"><img src="${p.thumb}" alt=""><div><p>Este video todavía no tiene enlace de Drive.</p><small>Pegá el link en <code>js/data.js</code> (campo <code>drive</code>) y se reproduce acá.</small></div></div>`;
    $('#p-drive').href = driveView(p.drive) || SITE.carpetaDrive;
    $('#p-drive').textContent = id ? 'Abrir en Drive' : 'Abrir carpeta de Drive';
    if (!dlg.open) dlg.showModal();
  }
  function close() { dlg.close(); }
  dlg.addEventListener('close', () => { frame.innerHTML = ''; if (lastFocus) lastFocus.focus(); });
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  $('#p-close').addEventListener('click', close);
  $('#p-prev').addEventListener('click', () => open(idx - 1));
  $('#p-next').addEventListener('click', () => open(idx + 1));
  dlg.addEventListener('keydown', e => { if (e.key === 'ArrowLeft') open(idx - 1); if (e.key === 'ArrowRight') open(idx + 1); });

  render();
})();
